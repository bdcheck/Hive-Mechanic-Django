actions.append({
    'type': 'echo',
    'message': definition['message']
})
actions.append({
    'type': 'echo-image',
    'image-url': definition['image']
})
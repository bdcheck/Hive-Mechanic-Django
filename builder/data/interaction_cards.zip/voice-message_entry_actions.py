actions.append({
    'type': 'echo-voice',
    'message': definition['message'],
    'next_action': definition['next_action']    
})
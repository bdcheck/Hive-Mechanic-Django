import re
import json
import random

# Incoming globals: definition, response, last_transition, previous_state

# Definition Example
#      {
#        "name": cardName, 
#        "scope": "player",
#        "mode": "random",
#        "branches": [{
#           "action": "node-1",
#           "action": "node-2",
#           "action": "node-3"
#        ], 
#        "type": "branch", 
#        "id": "branch-12345"
#      }, 

print('DEF: ' + json.dumps(definition, indent=2))
print('EXTRAS: ' + str(extras))

result['details'] = {}

result['actions'] = []
result['next_id'] = None

branch_cookie = 'branch-' + definition["id"] + '-visits' 

past_branches = None

if definition["scope"] == "player":
    past_branches = extras['player'].fetch_cookie(branch_cookie)
elif definition["scope"] == "session":
    past_branches = extras['session'].fetch_cookie(branch_cookie)
else: # Game
    past_branches = extras['session'].game_version.game.fetch_cookie(branch_cookie)
    
if past_branches is None:
    past_branches = ''
    
visits = []

next_index = 0

if past_branches:
    visits = past_branches.split(';')
   
print('VISITS: ' + str(visits))
 
if definition["mode"] == "random":
    next_index = random.randint(0, len(definition["branches"]) - 1)
elif definition["mode"] == "random-no-repeat":
    options = range(0, len(definition["branches"]))

    print('OPTIONS 1: ' + str(options))
    
    for visit in visits.sort(reverse=True):
        del options[int(visit)]

    print('OPTIONS 2: ' + str(options))
        
    if len(options) == 0:
        options = range(0, len(definition["branches"]))
        visits = []

    print('OPTIONS 3: ' + str(options))
    
    next_index = random.choice(options)
else: # Sequential
    if len(visits) > 0:
        next_index = len(visits) % len(definition["branches"])
    else:
        next_index = 0

visits.append(str(next_index))

next_action = definition["branches"][next_index]["action"]
    
result['details']['selected_index'] = next_index
result['details']['selected_action'] = next_action
result['details']['past_visits'] = visits
result['next_id'] = next_action

if result['next_id'] is not None and ('#' in result['next_id']) is False:
    result['next_id'] = definition['sequence_id'] + '#' + result['next_id']
    
action = {
    'type': 'set-cookie',
    'cookie': branch_cookie,
    'value': ';'.join(visits)
}

if 'scope' in definition:
    action['scope'] = definition['scope']

result['actions'] = [action]
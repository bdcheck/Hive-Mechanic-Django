go_on = {
    'type': 'continue'
}

actions.append(go_on)
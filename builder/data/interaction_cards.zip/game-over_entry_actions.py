end_activity = {
    'type': 'end-activity'
}

actions.append(end_activity)
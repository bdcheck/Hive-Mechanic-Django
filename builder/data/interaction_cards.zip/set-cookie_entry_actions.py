cookie = {
    'type': 'set-cookie',
    'cookie': definition['cookie'],
    'value': definition['value']
}

if 'scope' in definition:
    cookie['scope'] = definition['scope']

actions.append(cookie)
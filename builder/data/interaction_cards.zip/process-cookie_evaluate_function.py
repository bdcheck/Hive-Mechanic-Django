import re
import json

# Incoming globals: definition, response, last_transition, previous_state

# Definition Example
#      {
#        "message": "Are you ready to proceed? (Respond Y to continue.)", 
#        "next": "process-consent", 
#        "type": "send-message", 
#        "id": "request-consent-2", 
#        "name": "Request Consent"
#      }, 

print('DEF: ' + json.dumps(definition, indent=2))
print('EXTRAS: ' + str(extras))

result['details'] = {}

result['actions'] = []
result['next_id'] = None

cookie = extras['session'].fetch_cookie(definition['cookie'])

print('COOKIE: ' + str(cookie))

if cookie is None:
    cookie = ''
    
result['details']['fetched'] = cookie
result['details']['cookie'] = definition['cookie']
result['actions'] = []
result['next_id'] = None

for pattern_def in definition['patterns']:
    print('MATCH? ' + pattern_def['pattern'] + ' / ' + str(cookie) + ' --> ' + str(re.match(pattern_def['pattern'], cookie)))

    pattern = re.compile(pattern_def['pattern'], re.IGNORECASE)

    if result['next_id'] is None and pattern.match(cookie) is not None:
        result['next_id'] = pattern_def['action']
        result['matched_pattern'] = pattern_def['pattern']

if result['next_id'] is None and definition['not_found_action'] is not None:
    result['next_id'] = definition['not_found_action']
    result['matched_pattern'] = 'no-matches-found'

if result['next_id'] is not None and (#' in result['next_id']) is False:
    result['next_id'] = definition['sequence_id'] + '#' + result['next_id']